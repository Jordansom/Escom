public class MarkovLine {
    public static void main(String[] args) throws Exception {
        System.out.println("\n----\t Practica: Lineas de Markov \t----\n");
        System.out.println(
                "   Descripcion de la practica: El usuario ingresara la matriz de tranciosion del sistema o usara una por defecto, posteriormente el resultado sera el punto estable del sistema.\n");
        while (true) {
            int fyc;
            double matriz[][];
            System.out.println("   La matriz por defecto es:\n");
            System.out.println("    [0.5 ]  [0.3 ]   [0.2]");
            System.out.println("    [0.3 ]  [0.6 ]   [0.1]");
            System.out.println("    [0.25]  [0.35]   [0.4]");
            System.out.print(
                    "\nDesea usar la mariz por defecto? NO: n/N , SI: cualquier tecla: ");
            String resp = System.console().readLine();
            if (resp.equals("n") || resp.equals("N")) {
                while (true) {
                    while (true) {
                        System.out.print("\n   Ingrese la cantidad de filas y columnas: ");
                        String fi = System.console().readLine();
                        try {
                            fyc = Integer.valueOf(fi);
                            break;
                        } catch (Exception e) {
                            System.err.println(
                                    "\nIngrese valores enteros numericos para la cantidad de filas y columnas...");
                        }
                    }
                    System.out.print(
                            "\nLos datos ingresados son correctos? desea reingresarlos? NO: n/N , SI: cualquier tecla: ");
                    resp = System.console().readLine();
                    if (resp.equals("n") || resp.equals("N")) {
                        break;
                    }
                }
                matriz = new double[fyc][fyc];
                while (true) {
                    System.out.print("\n   Ingrese los valores de la matriz: \n");
                    double valor, sum = 0f;
                    String val;
                    for (int x = 0; x < fyc; x++) {
                        for (int y = 0; y < fyc; y++) {
                            while (true) {
                                System.out.print("    Valor de la posicion (" + (x + 1) + "," + (y + 1) + "): ");
                                val = System.console().readLine();
                                try {
                                    valor = Double.valueOf(val);
                                    matriz[x][y] = Math.round(valor * 10000.0) / 10000.0;
                                    sum += valor;
                                    break;
                                } catch (Exception e) {
                                    System.err.println("\nIngrese valores numericos para los valores...\n");
                                }
                            }
                        }
                        if (sum != 1f) {
                            System.out.println(
                                    "\nLos valores ingresados son incorrectos, ya que la suma de las probabilidades es diferente de 1, debera reingresar los valores....\n");
                            x--;
                        }
                        sum = 0;
                    }
                    System.out.print("\n   La matriz resultante es la siguiente: \n");
                    for (int x = 0; x < fyc; x++) {
                        for (int y = 0; y < fyc; y++) {
                            System.out.print("\t\t[" + matriz[x][y] + "]");
                        }
                        System.out.print("\n");
                    }
                    System.out.print(
                            "\nLos datos ingresados son correctos? desea reingresarlos? NO: n/N , SI: cualquier tecla: ");
                    resp = System.console().readLine();
                    if (resp.equals("n") || resp.equals("N")) {
                        break;
                    }
                }
            } else {
                fyc = 3;
                matriz = new double[fyc][fyc];
                matriz[0][0] = 0.5;
                matriz[0][1] = 0.3;
                matriz[0][2] = 0.2;

                matriz[1][0] = 0.3;
                matriz[1][1] = 0.6;
                matriz[1][2] = 0.1;

                matriz[2][0] = 0.25;
                matriz[2][1] = 0.35;
                matriz[2][2] = 0.4;
            }
            encontrarPuntoEstable(matriz);
            System.out.print(
                    "\nDesea comprobar otro sistema? NO: n/N , SI: cualquier tecla: ");
            resp = System.console().readLine();
            if (resp.equals("n") || resp.equals("N")) {
                System.out.println("\n");
                break;
            }
            System.out.println("\n");
        }
    }

    public static void encontrarPuntoEstable(double matriz[][]) {
        double val;
        int comp = 0;
        double matrizResultante[][] = new double[matriz.length][matriz.length];
        int cont = 0;
        while (true) {
            cont++;
            for (int x = 0; x < matriz.length; x++) {
                for (int y = 0; y < matriz.length; y++) {
                    val = 0;
                    for (int j = 0; j < matriz[0].length; j++) {
                        val += matriz[x][j] * matriz[j][y];
                        val = Math.round(val * 10000.0) / 10000.0;
                    }
                    matrizResultante[x][y] = val;
                }
            }

            for (int x = 0; x < matriz.length; x++) {
                for (int y = 0; y < matriz.length; y++) {
                    matriz[x][y] = matrizResultante[x][y];
                }
            }

            for (int x = 0; x < matriz.length; x++) {
                for (int y = 0; y < matriz.length; y++) {
                    if (comp == 0) {
                        if (matriz[0][x] == matriz[y][x]) {
                            comp = 1;
                        }
                    } else {
                        if (matriz[0][x] != matriz[y][x]) {
                            comp = 0;
                            x = matriz.length;
                            y = matriz.length;
                        }
                    }
                }
            }
            if (comp == 1) {
                if (matriz[0][0] > 1) {
                    System.out.println(
                            "\nERROR. La matriz a resolver por cuestiones del redondeo de decimales no se puede resolver, reduzca los decimales ingresados o intente redondear.\n");
                }
                break;
            }
            if (cont > 100) {
                System.out.println(
                        "\nERROR. La matriz a resolver por cuestiones del redondeo de decimales no puede converger en un solo valor, tome solamente los decimales iguales.\n");
                break;
            }
        }
        System.out.print("\n   La matriz en su punto estable es la siguiente: \n");
        for (int x = 0; x < matriz.length; x++) {
            for (int y = 0; y < matriz.length; y++) {
                System.out.print("\t\t[" + matriz[x][y] + "]");
            }
            System.out.print("\n");
        }
    }
}
